# ML based rPPG construction

Manuscript: A Machine Learning–Based Approach for Constructing Remote Photoplethysmogram Signals from Video Cameras. 

Authors: Rodrigo Castellano Ontiveros, Mohamed Elgendi, and Carlo Menon. Code written by Rodrigo Castellano Ontiveros. BMHT lab, ETH, master thesis project.
